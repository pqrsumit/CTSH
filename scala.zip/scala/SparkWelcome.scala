import org.apache.spark.{SparkConf, SparkContext}
import scala.io.Source.fromFile

object SparkWelcome {
  def main(args: Array[String]): Unit = {

    println("Welcome Scala ")

    val conf = new SparkConf().setMaster("local[2]").setAppName("From my Local Machine")
    val sc = new SparkContext(conf)



    val rawFlight =       sc.textFile("F:\\Spark-Data\\data-master\\CTS-Demo\\Scripts-Commands\\CTSH\\Aircrafts.txt")

//    rawFlight.take(10).foreach(println)

    val rawFlightHeader= rawFlight.first()

//    println(rawFlightHeader)

    val rawFlightNoHeader = rawFlight.filter(row => row != rawFlightHeader )
    rawFlightNoHeader.take(10).foreach(println)
    val justFlight = rawFlightNoHeader.map(row=>row.split("\t")(0))
    val justFlightPaired = justFlight.map(flightString=>(flightString,1))

//  Using reduceByKey
//    val CountByFlight = justFlightPaired.reduceByKey((x,y)=>x+y)

//    Using GroupByKey

    val justFlightGroupBy = justFlightPaired.groupByKey()

    val CountByFlight = justFlightGroupBy
      .map(data => (data._1,data._2.iterator.toList.sum)) // (Boeing-787,6)
      .map(row=>(row._2,row._1)) // (6,Boeing-787)
      .sortByKey(false)
      .map(row=>(row._2,row._1))// (Boeing-787,6)

    val TotalSeatsByFlight = rawFlightNoHeader.map(row=>(row.split("\t")(0)
      ,row.split("\t")(1).toInt)).reduceByKey((Total,ThisFlight)=>Total+ThisFlight)
//    TotalSeatsByFlight.foreach(println)

//    CountByFlight.foreach(println)


    val TotalandCountByFlight = CountByFlight.join(TotalSeatsByFlight)
//    TotalandCountByFlight.foreach(println)
//    val TotalandCountByFlightnew =

//    val finalResult = TotalandCountByFlight.map(row=>row.productIterator.mkString(","))
//    (Boeing-777,(4,340))
    val finalResult = TotalandCountByFlight.map(row=>row._1+","+row._2._1.toString+","+row._2._2.toString)

    finalResult.take(10).foreach(println)

//    val tmp = sc.textFile("F:\\Spark-Data\\data-master\\CTS-Demo\\Aircrafts.txt",2)
//    tmp.map(r=>(r.length,r)).sortByKey(false,1).foreach(println)
    sc.stop()
  }

}
