package StrcutStream


import org.apache.spark.sql.{SparkSession, streaming}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.{ProcessingTime, Trigger}


object SparkSQLStream {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .master("local[2]")
      .appName("Spark SQL Batch Demo")
      .getOrCreate()

    import spark.implicits._
    spark.conf.set("spark.sql.shuffle.partitions",2)
    spark.sparkContext.setLogLevel("WARN")

//    Get the passenger data in memory
val passengerPersonalDetailsSchema = new StructType()
  .add("DOB",StringType)
  .add("Gender",StringType)
  .add("MealPreference",StringType)


    val passengerMoreDetailsSchema =  new StructType()
      .add("Passport",StringType)
      .add(StructField("PersonalDetails",passengerPersonalDetailsSchema))


    val passengerRootSchema = new StructType()
      .add("FirstName",StringType)
      .add("LastName",StringType)

      .add(StructField("MoreDetails",passengerMoreDetailsSchema
        ,false
        ,Metadata.fromJson("{\"Nested\":\"yes\"}"))
      )
      .add("randomint",FloatType)

    val passenger = spark.read
      .schema(passengerRootSchema)
      .json("F:\\Spark-Data\\data-master\\CTS-Demo\\Scripts-Commands\\CTSH\\Passengers.json")
    passenger.createOrReplaceGlobalTempView("passenger")
    passenger.show()
    passenger.printSchema()

//    val tripsSchema =  new StructType()
//      .add("TailNumber",StringType)
//      .add("Origin",StringType)
//      .add("Destination",StringType)
//      .add("TravelDate",DateType)
//      .add("TotalFlightTime",IntegerType)
//      .add("Revenue",FloatType)
//      .add("AircraftName",StringType)
//      .add("FirstName",StringType)
//      .add("Passport",StringType)
//      .add("Passport",StringType)

    val SocketTextStream = spark.readStream
      .format("socket")
      .option("host","localhost")
      .option("port","9999")
      .option("includeTimestamp","true")
//      .schema(tripsSchema)
      .load().withWatermark("timestamp","10 minutes")
//      .printSchema()
    SocketTextStream.createOrReplaceTempView("trips")
////A3016,LAS,DTW,2020-03-05,6,449.15,Airbus-A340,Russell,Constantine,G-14914714
//      spark.sql(" SELECT TailNumber ,TravelDate,ROUND(SUM(Revenue),2) AS Revenue FROM " +
//        " ( SELECT split(value,',')[0] AS TailNumber " +
//        " , split(value,',')[1] AS Origin " +
//        " , split(value,',')[2] AS Destination " +
//        " , CAST(split(value,',')[3] AS DATE) AS TravelDate " +
//        " , CAST(split(value,',')[4] AS INT) AS TotalFlightTime "
//        + " ,CAST(split(value,',')[5] AS FLOAT) AS Revenue " +
//        " , split(value,',')[9] AS Passport " +
//    " FROM trips )MyInnerQuery  WHERE Origin='ATL' GROUP BY TailNumber ,TravelDate ")

        spark.sql("SELECT split(T.value,',')[1] AS Origin,split(T.value,',')[2] AS Destination ,CAST(split(T.value,',')[3] AS DATE) AS TravelDate ,split(T.value,',')[9] AS Passport ,P.FirstName ,P.LastName ,decode(unbase64(P.MoreDetails.PersonalDetails.DOB),'UTF-8')AS DOB FROM trips T JOIN global_temp.passenger P ON split(T.value,',')[9] = P.MoreDetails.Passport")

          .writeStream
      .format("console")
      .option("truncate","false")
      .outputMode("update")
      .trigger(Trigger.ProcessingTime("1 minutes"))
      .queryName("RunningAggEveryMinForATL")
      .start()
        .awaitTermination()

  }

}
