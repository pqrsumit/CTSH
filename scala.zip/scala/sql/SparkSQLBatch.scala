package sql

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

object SparkSQLBatch {

  def main(args: Array[String]): Unit = {
    println("Scala is working")

    val spark = SparkSession.builder()
      .master("local[2]")
      .appName("Spark SQL Batch Demo")
      .getOrCreate()

    import spark.implicits._
    spark.conf.set("spark.sql.shuffle.partitions",2)
    spark.sparkContext.setLogLevel("WARN")

    val    AircraftRawDataschema = new StructType()
      .add("AircraftName",StringType)
      .add("Capacity",IntegerType)
      .add("TailNumber",StringType)

    val AircraftRawData = spark.read
        .option("sep","\t")
      .option("header","true")
//      .option("inferschema","true")
//      .schema(AircraftRawDataschema)
        .csv("F:\\Spark-Data\\data-master\\CTS-Demo\\Scripts-Commands\\CTSH\\Aircrafts.txt")
//    AircraftRawData.printSchema()
//    AircraftRawData.show()

    val AircraftDataCast = AircraftRawData.withColumn("CapacityInt",col("Capacity").cast(IntegerType))

//    AircraftDataCast.printSchema()
//    AircraftDataCast.show()


//    AircraftRawData.write
//        .mode("overwrite")
//      .orc("F:\\Spark-Data\\data-master\\CTS-Demo\\Scripts-Commands\\CTSH\\Output\\Aircrafts.orc")
    AircraftRawData.write
      .mode("overwrite")
          .format("json")
          .save("F:\\Spark-Data\\data-master\\CTS-Demo\\Scripts-Commands\\CTSH\\Output\\Aircrafts.json")

    val AircraftJSON = spark.read
      .json("F:\\Spark-Data\\data-master\\CTS-Demo\\Scripts-Commands\\CTSH\\Output\\Aircrafts.json\\")

//    AircraftJSON.show()
    ////    AircraftJSON.printSchema()
    AircraftJSON.write
      .mode("overwrite")
      .parquet("F:\\Spark-Data\\data-master\\CTS-Demo\\Scripts-Commands\\CTSH\\Output\\Aircraft.Parquet")

    AircraftJSON.write.format("avro")
      .mode("overwrite")
      .save("F:\\Spark-Data\\data-master\\CTS-Demo\\Scripts-Commands\\CTSH\\Output\\Aircraft.Avro")

    val data = Seq(("Hi",1,2L)).toDF("c1","c2","c3")
//    data.printSchema()

    val passengerPersonalDetailsSchema = new StructType()
      .add("DOB",StringType)
      .add("Gender",StringType)
      .add("MealPreference",StringType)


    val passengerMoreDetailsSchema =  new StructType()
      .add("Passport",StringType)
      .add(StructField("PersonalDetails",passengerPersonalDetailsSchema))


    val passengerRootSchema = new StructType()
      .add("FirstName",StringType)
      .add("LastName",StringType)

      .add(StructField("MoreDetails",passengerMoreDetailsSchema
        ,false
      ,Metadata.fromJson("{\"Nested\":\"yes\"}"))
      )
      .add("randomint",FloatType)




    val passenger = spark.read
        .schema(passengerRootSchema)
      .json("F:\\Spark-Data\\data-master\\CTS-Demo\\Scripts-Commands\\CTSH\\Passengers.json")
//    passenger.printSchema()
//    passenger.show(10)

    passenger.createOrReplaceTempView("passenger")
    AircraftRawData.createOrReplaceTempView("AircraftRawData")
    spark.read
      .option("header","true")
      .csv("F:\\Spark-Data\\data-master\\CTS-Demo\\Scripts-Commands\\CTSH\\Trips.csv")
      .createOrReplaceTempView("trips")

    val passengerdf = passenger.withColumn("DOB"
      ,decode(unbase64($"MoreDetails.PersonalDetails.DOB"),"UTF-8"))
        .drop("MoreDetails","randomint")
    passengerdf.show()
//    spark
//      .sql(" SELECT CAST(randomint AS INT),FirstName,LastName AS randomint ,MoreDetails.Passport " +
//        " ,decode(unbase64(MoreDetails.PersonalDetails.DOB),\"UTF-8\") AS DOB " +
//      " FROM passenger ")
//      .show()
  }

}
